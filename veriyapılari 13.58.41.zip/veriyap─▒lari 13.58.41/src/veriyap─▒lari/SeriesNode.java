package veriyapılari;

public class SeriesNode {
    int seriesID;
    String title;
    String category;
    char ageClass;
    EpisodeNode episodeListHead;
    SeriesNode next;
    SeriesNode prev;

    public SeriesNode(int id, String title, String category, char age) {
        this.seriesID = id;
        this.title = title;
        this.category = category;
        this.ageClass = age;
        this.episodeListHead = null;
        this.next = null;
        this.prev = null;
    }
}