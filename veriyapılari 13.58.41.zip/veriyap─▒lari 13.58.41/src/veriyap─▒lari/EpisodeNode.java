package veriyapılari;

public class EpisodeNode {
    int seriesId;
    int seasonId;
    int episodeId;
    String episodeCaption;
    String director;
    
    EpisodeNode next; 
    EpisodeNode prev; 
    public EpisodeNode(int sId, int seasId, int epId, String cap, String dir) {
        this.seriesId = sId;
        this.seasonId = seasId;
        this.episodeId = epId;
        this.episodeCaption = cap;
        this.director = dir;
        this.next = null;
        this.prev = null;
    }
}