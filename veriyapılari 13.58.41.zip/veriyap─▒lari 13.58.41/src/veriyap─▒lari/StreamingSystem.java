
package veriyapılari;

import java.io.*;
import java.util.Scanner;

public class StreamingSystem {

	SeriesNode head = null;

	// --- 1. ADD SERIES (Sorted by ID) ---
	public void addSeries(int id, String title, String cat, char age) {
		SeriesNode newNode = new SeriesNode(id, title, cat, age);

		// Case 1: List is empty
		if (head == null) {
			head = newNode;
			return;
		}

		// Case 2: Insert at the beginning (Head)
		if (head.seriesID > id) {
			newNode.next = head;
			head.prev = newNode;
			head = newNode;
			return;
		}

		// Case 3: Insert middle or end
		SeriesNode current = head;
		while (current.next != null && current.next.seriesID < id) {
			current = current.next;
		}

		// Check for Duplicate ID
		if (current.seriesID == id || (current.next != null && current.next.seriesID == id)) {
			// Error message is commented out to keep loadData clean
			// System.out.println("Error: Series with ID " + id + " already exists!");
			return;
		}

		// Linking the nodes
		newNode.next = current.next;
		if (current.next != null) {
			current.next.prev = newNode;
		}
		current.next = newNode;
		newNode.prev = current;
	}

	// --- 2. REMOVE SERIES ---
	public void removeSeries(String title) {
		if (head == null) {
			System.out.println("List is empty.");
			return;
		}

		SeriesNode current = head;
		// Find series by title
		while (current != null && !current.title.equalsIgnoreCase(title)) {
			current = current.next;
		}

		if (current == null) {
			System.out.println("Series not found: " + title);
			return;
		}

		// Update pointers to remove node
		if (current == head) {
			head = head.next;
			if (head != null) {
				head.prev = null;
			}
		} else {
			current.prev.next = current.next;
			if (current.next != null) {
				current.next.prev = current.prev;
			}
		}
		System.out.println("Series '" + title + "' and all its episodes have been deleted.");
	}

	// --- 3. ADD EPISODE ---
	public void addEpisode(int sId, int season, int epId, String cap, String dir) {
		SeriesNode currentSeries = head;
		while (currentSeries != null) {
			if (currentSeries.seriesID == sId)
				break;
			currentSeries = currentSeries.next;
		}

		if (currentSeries == null)
			return; // Series not found, skip

		EpisodeNode newEp = new EpisodeNode(sId, season, epId, cap, dir);

		// Add to end of episode list
		if (currentSeries.episodeListHead == null) {
			currentSeries.episodeListHead = newEp;
		} else {
			EpisodeNode temp = currentSeries.episodeListHead;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = newEp;
			newEp.prev = temp;
		}
	}

	// --- 4. EDIT EPISODE ---
	public void editEpisode(int sId, int epId, String newCaption, String newDirector) {
		SeriesNode sNode = head;
		while (sNode != null && sNode.seriesID != sId) {
			sNode = sNode.next;
		}
		if (sNode == null) {
			System.out.println("Series not found.");
			return;
		}

		EpisodeNode eNode = sNode.episodeListHead;
		while (eNode != null && eNode.episodeId != epId) {
			eNode = eNode.next;
		}
		if (eNode == null) {
			System.out.println("Episode not found.");
			return;
		}

		eNode.episodeCaption = newCaption;
		eNode.director = newDirector;
		System.out.println("Episode updated successfully.");
	}

	// --- LISTING & SEARCH FUNCTIONS ---

	public void printAllSeries() {
		System.out.println("\n--- RECORDED SERIES ---");
		SeriesNode temp = head;
		if (temp == null)
			System.out.println("List is empty.");
		while (temp != null) {
			System.out.println("ID: " + temp.seriesID + " | Title: " + temp.title + " | Category: " + temp.category
					+ " | Age: " + temp.ageClass);
			temp = temp.next;
		}
	}

	public void listEpisodesOfSeries(String seriesTitle) {
		SeriesNode temp = head;
		while (temp != null) {
			if (temp.title.equalsIgnoreCase(seriesTitle))
				break;
			temp = temp.next;
		}
		if (temp == null) {
			System.out.println("Series not found!");
			return;
		}

		System.out.println("\n--- EPISODES OF " + temp.title.toUpperCase() + " ---");
		EpisodeNode ep = temp.episodeListHead;
		if (ep == null)
			System.out.println("No episodes found.");

		while (ep != null) {
			System.out.println(
					"S" + ep.seasonId + ".E" + ep.episodeId + ": " + ep.episodeCaption + " [Dir: " + ep.director + "]");
			ep = ep.next;
		}
	}

	public void searchDirector(String directorName) {
		SeriesNode sNode = head;
		boolean found = false;
		System.out.println("\n--- SEARCH RESULTS FOR DIRECTOR: " + directorName + " ---");
		while (sNode != null) {
			EpisodeNode eNode = sNode.episodeListHead;
			while (eNode != null) {
				if (eNode.director.trim().equalsIgnoreCase(directorName.trim())) {
					System.out.println("Series: " + sNode.title + " | Episode: " + eNode.episodeCaption);
					found = true;
				}
				eNode = eNode.next;
			}
			sNode = sNode.next;
		}
		if (!found)
			System.out.println("No records found for this director.");
	}

	public void searchAgeClass(char age) {
		System.out.println("\n--- SEARCH RESULTS FOR AGE CLASS: " + age + " ---");
		SeriesNode temp = head;
		boolean found = false;
		while (temp != null) {
			if (temp.ageClass == age) {
				System.out.println("- " + temp.title);
				found = true;
			}
			temp = temp.next;
		}
		if (!found)
			System.out.println("No series found in this age class.");
	}

	public void searchCategory(String category) {
		System.out.println("\n--- SEARCH RESULTS FOR CATEGORY: " + category + " ---");
		SeriesNode temp = head;
		boolean found = false;
		while (temp != null) {
			if (temp.category.trim().equalsIgnoreCase(category.trim())) {
				System.out.println("- " + temp.title);
				found = true;
			}
			temp = temp.next;
		}
		if (!found)
			System.out.println("No series found in this category.");
	}

	// --- FILE OPERATIONS (LOAD & SAVE) ---

	public void loadData() {
		File fSeries = new File("series.txt");
		File fEp = new File("episodes.txt");

		System.out.println("[INFO] Working Directory: " + fSeries.getAbsolutePath());

		// Create files if they don't exist
		try {
			if (!fSeries.exists()) {
				fSeries.createNewFile();
				System.out.println("[INFO] series.txt created.");
			}
			if (!fEp.exists()) {
				fEp.createNewFile();
				System.out.println("[INFO] episodes.txt created.");
			}
		} catch (IOException e) {
			System.out.println("[ERROR] Could not create files: " + e.getMessage());
			return;
		}

		// Read Series
		try (BufferedReader br = new BufferedReader(new FileReader(fSeries))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(",");
				if (parts.length >= 4) {
					addSeries(Integer.parseInt(parts[0].trim()), parts[1].trim(), parts[2].trim(),
							parts[3].trim().charAt(0));
				}
			}
		} catch (Exception e) {
			System.out.println("Error reading series.txt: " + e.getMessage());
		}

		// Read Episodes
		try (BufferedReader brEp = new BufferedReader(new FileReader(fEp))) {
			String lineEp;
			while ((lineEp = brEp.readLine()) != null) {
				String[] parts = lineEp.split(",");
				if (parts.length >= 5) {
					addEpisode(Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim()),
							Integer.parseInt(parts[2].trim()), parts[3].trim(), parts[4].trim());
				}
			}
		} catch (Exception e) {
			System.out.println("Error reading episodes.txt: " + e.getMessage());
		}
	}

	public void saveData() {
		System.out.println("Saving data...");
		try {
			BufferedWriter bwSeries = new BufferedWriter(new FileWriter("series.txt"));
			BufferedWriter bwEp = new BufferedWriter(new FileWriter("episodes.txt"));

			SeriesNode sTemp = head;
			while (sTemp != null) {
				// Write Series
				bwSeries.write(sTemp.seriesID + "," + sTemp.title + "," + sTemp.category + "," + sTemp.ageClass);
				bwSeries.newLine();

				// Write Episodes for this series
				EpisodeNode eTemp = sTemp.episodeListHead;
				while (eTemp != null) {
					bwEp.write(eTemp.seriesId + "," + eTemp.seasonId + "," + eTemp.episodeId + "," +
							eTemp.episodeCaption + "," + eTemp.director);
					bwEp.newLine();
					eTemp = eTemp.next;
				}
				sTemp = sTemp.next;
			}
			bwSeries.close();
			bwEp.close();
			System.out.println("✔ SUCCESS: All data saved to files.");

		} catch (IOException e) {
			System.out.println("SAVE ERROR: " + e.getMessage());
		}
	}

	// --- MAIN METHOD ---
	public static void main(String[] args) {
		StreamingSystem system = new StreamingSystem();
		Scanner scanner = new Scanner(System.in);

		System.out.println("Loading data from files...");
		system.loadData();

		while (true) {
			System.out.println("\n=== STREAMING PLATFORM MANAGEMENT SYSTEM ===");
			System.out.println("1. Add Series");
			System.out.println("2. Remove Series");
			System.out.println("3. Print All Series");
			System.out.println("4. Add Episode");
			System.out.println("5. Edit Episode");
			System.out.println("6. List Episodes of Series");
			System.out.println("7. Search Director");
			System.out.println("8. Search Age Class");
			System.out.println("9. Search Category");
			System.out.println("10. SAVE & EXIT");
			System.out.print("Select an option: ");

			int choice;
			try {
				choice = scanner.nextInt();
				scanner.nextLine(); // consume newline
			} catch (Exception e) {
				System.out.println("Invalid input. Please enter a number.");
				scanner.nextLine();
				continue;
			}

			if (choice == 10) {
				system.saveData();
				System.out.println("Exiting program. Goodbye!");
				break;
			}

			switch (choice) {
				case 1:
					System.out.print("Enter Series ID: ");
					int id = scanner.nextInt();
					scanner.nextLine();
					System.out.print("Enter Title: ");
					String title = scanner.nextLine();
					System.out.print("Enter Category: ");
					String cat = scanner.nextLine();
					System.out.print("Enter Age Class (e.g., A, B): ");
					char age = scanner.nextLine().charAt(0);
					system.addSeries(id, title, cat, age);
					break;
				case 2:
					System.out.print("Enter Title of Series to Remove: ");
					String rTitle = scanner.nextLine();
					system.removeSeries(rTitle);
					break;
				case 3:
					system.printAllSeries();
					break;
				case 4:
					System.out.print("Enter Series ID to add episode to: ");
					int sId = scanner.nextInt();
					System.out.print("Enter Season ID: ");
					int seaId = scanner.nextInt();
					System.out.print("Enter Episode ID: ");
					int epId = scanner.nextInt();
					scanner.nextLine();
					System.out.print("Enter Episode Caption: ");
					String cap = scanner.nextLine();
					System.out.print("Enter Director Name: ");
					String dir = scanner.nextLine();
					system.addEpisode(sId, seaId, epId, cap, dir);
					break;
				case 5:
					System.out.print("Enter Series ID: ");
					int eSId = scanner.nextInt();
					System.out.print("Enter Episode ID: ");
					int eEpId = scanner.nextInt();
					scanner.nextLine();
					System.out.print("Enter New Caption: ");
					String nCap = scanner.nextLine();
					System.out.print("Enter New Director: ");
					String nDir = scanner.nextLine();
					system.editEpisode(eSId, eEpId, nCap, nDir);
					break;
				case 6:
					System.out.print("Enter Series Title: ");
					String lTitle = scanner.nextLine();
					system.listEpisodesOfSeries(lTitle);
					break;
				case 7:
					System.out.print("Enter Director Name: ");
					String sDir = scanner.nextLine();
					system.searchDirector(sDir);
					break;
				case 8:
					System.out.print("Enter Age Class: ");
					char sAge = scanner.nextLine().charAt(0);
					system.searchAgeClass(sAge);
					break;
				case 9:
					System.out.print("Enter Category: ");
					String sCat = scanner.nextLine();
					system.searchCategory(sCat);
					break;
				default:
					System.out.println("Invalid selection. Please try again.");
			}
		}
		scanner.close();
	}
}